export class Routess {
    public route_id: number;
	public source: string;
	public destination: string;
	public distance: number;
	public costperkm: number;
	public duration: string;
}
