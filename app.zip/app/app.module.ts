import { BrowserModule } from '@angular/platform-browser';
import { NgModule, Component } from '@angular/core';
import 'zone.js';
import 'reflect-metadata';

import { HttpModule } from '@angular/http';

import { AppComponent } from './app.component';
import { SearchShipComponent } from './search-ship/search-ship.component';

import { CustomerService } from './customer.service';
import { RouterModule, Routes } from '@angular/router';
import { provideForRootGuard } from '@angular/router/src/router_module';
import { ScheduleDetailsComponent } from './schedule-details/schedule-details.component';
import {  FormsModule, ReactiveFormsModule } from '@angular/forms';
import { BookTicketsComponent } from './book-tickets/book-tickets.component';
import { CusProfileIdComponent } from './cus-profile-id/cus-profile-id.component';
import { SearchTicketComponent } from './search-ticket/search-ticket.component';
import { PaymentGatewayComponent } from './payment-gateway/payment-gateway.component';
import { SuccessComponent } from './success/success.component';
import { HomeComponent } from './home/home.component';
import { AddcustomerComponent } from './addcustomer/addcustomer.component';
import { LoginComponent } from './login/login.component';
import { AboutUsComponent } from './about-us/about-us.component';
import { UpdateComponent } from './update/update.component';

const appRoutes: Routes= [

  { path: 'customer/:id', component: CusProfileIdComponent },

  { path: 'searchship', component: SearchShipComponent },
  { path: 'bookingstatus', component: SearchTicketComponent },
  { path: 'add', component: BookTicketsComponent },
  { path: 'schedule', component: SearchShipComponent },
  { path: 'schedules', component: ScheduleDetailsComponent },
  {path: '', component:ScheduleDetailsComponent},
  {path: 'home', component:HomeComponent},
  {path: 'payment', component:PaymentGatewayComponent},
  {path: 'success', component:SuccessComponent},
  {path: 'login', component:LoginComponent},
  {path: 'signup', component:AddcustomerComponent},
  {path: 'aboutus', component:AboutUsComponent},
  {path: 'update/:id', component:UpdateComponent},
  {path: 'profile', component:CusProfileIdComponent}
];
  

@NgModule({
  declarations: [
    AppComponent,
  

    SearchShipComponent,
 
    ScheduleDetailsComponent,
    BookTicketsComponent,
    CusProfileIdComponent,
    SearchTicketComponent,
    PaymentGatewayComponent,
    SuccessComponent,
    HomeComponent,
    AddcustomerComponent,
    LoginComponent,
    AboutUsComponent,
    UpdateComponent
  
  ],
  imports: [
    BrowserModule,
    HttpModule,
    FormsModule,
    RouterModule.forRoot(appRoutes)
  ],
  providers: [ CustomerService ],
  bootstrap: [AppComponent]
})
export class AppModule { }
