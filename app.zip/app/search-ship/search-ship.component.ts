import { Component, OnInit } from '@angular/core';
import { Schedule } from '../schedule';
import { ScheduleService } from '../schedule.service';
import { Router } from '@angular/router';
import { Ship } from '../ship';
import { Routess } from '../routess';


@Component({
  selector: 'app-search-ship',
  templateUrl: './search-ship.component.html',
  styleUrls: ['./search-ship.component.css'],
  providers: [ScheduleService]
})
export class SearchShipComponent implements OnInit {

  model: any = {};
 // loading = false;
  error = 'invalid ';
  schedule :Schedule[];
 // passengerDetails:PassengerDetails;
  statusCode: number;
  
  constructor(private _scheduleService: ScheduleService,
    private router: Router){ } 

  ngOnInit() {
    this.search();
  }
  private search(): any{
    return  this._scheduleService.getSchedule(this.model.source,this.model.destination,this.model.departure)
    .subscribe(
      data => this.schedule = data,
      errorCode =>  this.statusCode = errorCode); 
    }
   /* if(flight != null ) {
      this.router.navigateByUrl('app/customer-search');
    } else {
      this.error ='Sorry no flights match your criteria';
      this.loading = false;
      console.log(this.error);
    }}) ;
  }*/
 //private book():any{
  //  return this._scheduleService.bookFlights(this.passengerDetails);
  // }
  
  }
