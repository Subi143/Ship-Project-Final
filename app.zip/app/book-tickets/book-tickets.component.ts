import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Passenger } from '../passenger';
import { FormGroup, Validators, FormControl } from '../../../node_modules/@angular/forms';
import { PassengerService } from '../passenger.service';

@Component({
  selector: 'app-book-tickets',
  templateUrl: './book-tickets.component.html',
  styleUrls: ['./book-tickets.component.css'],
  providers: [PassengerService]
})
export class BookTicketsComponent {
    passenger=new Passenger();
    booking_Form: FormGroup;
      
     seatno= new FormControl("", Validators.required); 
      
      fname = new FormControl("", Validators.required);
     age = new FormControl("", Validators.required);
  
      
  
      constructor(private _passengerService: PassengerService,private router: Router
      ) {}
  
      
      submitted = false;
      ngOnInit() {
      }
    
      
      private save(): void {
        this._passengerService.book(this.passenger);
        this.router.navigate(['/payment']);
      }
    
      onSubmit() {
        this.submitted = true;
        this.save();
      }
    }


