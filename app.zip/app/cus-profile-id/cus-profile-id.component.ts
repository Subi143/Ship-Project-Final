import { Component, OnInit } from '@angular/core';
import { Customer } from '../customer';
import { ActivatedRoute, Router } from '@angular/router';
import { CustomerService } from '../customer.service';
import { PassengerService } from '../passenger.service';

@Component({
  selector: 'app-cus-profile-id',
  templateUrl: './cus-profile-id.component.html',
  styleUrls: ['./cus-profile-id.component.css'],
  providers: [CustomerService]
})
export class CusProfileIdComponent {
  model: any = {};
  // loading = false;
   error = 'invalid ';
   customers :Customer;
  // passengerDetails:PassengerDetails;
   statusCode: number;
   
   constructor(private _customerService: CustomerService,
     private router: Router){ } 
 
   ngOnInit() {
     //this.search();
   }
   private search(): any{
     return  this._customerService.getCustomerById(this.model.id)
     .subscribe(
       data => this.customers = data,
       errorCode =>  this.statusCode = errorCode); 
     }
    }
