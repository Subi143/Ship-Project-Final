import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { CusProfileIdComponent } from './cus-profile-id.component';

describe('CusProfileIdComponent', () => {
  let component: CusProfileIdComponent;
  let fixture: ComponentFixture<CusProfileIdComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CusProfileIdComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CusProfileIdComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
