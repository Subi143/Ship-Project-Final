import { Injectable } from '@angular/core';
import { Http, Headers, Response } from "../../node_modules/@angular/http";
import { Observable } from "../../node_modules/rxjs";
import 'rxjs/add/operator/map';
import 'rxjs/add/operator/catch';
import 'rxjs/add/observable/throw';
import { Customer } from "./customer";

@Injectable()
export class UserService {
  createCustomer(arg0: any): any {
    throw new Error("Method not implemented.");
  }
  private customernurl='http://localhost:8089/ShipProject/login';
  private headers = new Headers({'Content-Type': 'application/json'});

  constructor(private _http:Http) { }


  login(email:string,password:string):Promise<boolean>{
    var lurl=`${this.customernurl}/${email}/${password}`;
  
   return this._http.get(lurl,JSON.stringify({email:email,password:password}))
   .toPromise()
   .then(response => {
     let customer=response.json() && response.json().Customer;
     console.log(response.text());
     if(response.text()==="true"){
       return true;
     }
     else{
       return false;
     }
   })
   .catch(this.handleError);
   }

 create(customer: Customer): Promise<Customer> {
    return this._http
      .post('http://localhost:8089/ShipProject/insert', JSON.stringify(customer), {headers : this.headers})
      .toPromise()
      .then(res => res.json() as Customer)
      .catch(this.handleError);
  }
  private handleError(error: any): Promise<any> {
    console.error('Error', error); // for demo purposes only
    return Promise.reject(error.message || error);
  }
}