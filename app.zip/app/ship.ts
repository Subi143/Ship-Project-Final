export class Ship {
    public id: number;
	public name: string;
	public capacity: number;
	public concapacity: number;
	public wlcapacity: number;
}
