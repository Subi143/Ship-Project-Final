import { Component, OnInit } from '@angular/core';
import { Customer } from '../customer';
import { CustomerService } from '../customer.service';
import { FormGroup, FormControl, Validators } from '../../../node_modules/@angular/forms';
import { UserService } from '../user.service';
import { Router } from '../../../node_modules/@angular/router';
@Component({
  selector: 'app-addcustomer',
  templateUrl: './addcustomer.component.html',
  styleUrls: ['./addcustomer.component.css'],
  providers: [ UserService ]

})
export class AddcustomerComponent {
  customer=new Customer();
  registration_Form: FormGroup;
    
    email = new FormControl("", Validators.required); 
    
    mobile = new FormControl("", Validators.required);
    password = new FormControl("", Validators.required);

    

    constructor(private _customerService: UserService,private router: Router
    ) {}

    
    submitted = false;
    ngOnInit() {
    }
  
    
    private save(): void {
      this._customerService.create(this.customer);
      this.router.navigate(['/login']);
    }
  
    onSubmit() {
      this.submitted = true;
      this.save();
    }
  
    
    
}




