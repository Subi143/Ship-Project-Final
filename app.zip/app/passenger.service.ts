import { Injectable } from '@angular/core';
import { Schedule } from './schedule';
import { Headers,Http } from '@angular/http';
import { Observable } from 'rxjs';
import 'rxjs/add/operator/map';
import 'rxjs/add/operator/catch';
import { Ship } from './ship';
import { Passenger } from './passenger';

@Injectable()
export class PassengerService {

  schedulelist:Passenger[];
  private headers = new Headers({'Content-Type':'application/json'})

  constructor(private _http:Http) { }

  getPassenger(customer_id: number):Observable<Passenger[]> {
    const url='http://localhost:8089/ShipProject/passenger';
    const getpassengerUrl=`${url}/${customer_id}`;
    return this._http.get(getpassengerUrl,{headers :this.headers})
    .map(response => response.json() as Passenger)
    .catch(this.handleError);
    
  }

  getPassengerByBookingId(booking_id:number):Observable<Passenger>{
    const url='http://localhost:8089/ShipProject/passenger';
    const getpassengerUrl=`${url}/${booking_id}`;
    return this._http.get(getpassengerUrl,{headers :this.headers})
   // .map(response =>{response.json() as Passenger,console.log(response)})
    .catch(this.handleError);
    
  }


  getPassengerByBookingId1(booking_id:number):Observable<Passenger>{
    const url='http://localhost:8089/ShipProject/passenger';
    const getpassengerUrl=`${url}/${booking_id}`;
    return this._http.get(getpassengerUrl,{headers :this.headers})
    .map(response =>response.json() as Passenger)
    .catch(this.handleError);
    
  }
  book(passenger: Passenger): Promise<Passenger> {
    return this._http
      .post('http://localhost:8089/ShipProject/add', JSON.stringify(passenger), {headers : this.headers})
      .toPromise()
      .then(res => res.json() as Passenger)
      .catch(this.handleError);
  }
//  updatePassenger(passenger:Passenger,booking_id: number):Observable<Passenger>{
//   const url='http://localhost:8089/ShipProject/edit';
//   const url1=`${url}/${booking_id}`;
//     return this._http.put(url1,JSON.stringify(passenger))
//     .map(res => res.json() as Passenger)
//     .catch(this.handleError);
//   }

  updatePassenger(booking_id: number):Observable<Passenger>{
    const url='http://localhost:8089/ShipProject/edit';
    const url1=`${url}/${booking_id}`;
    return this._http.put(url1,{headers :this.headers})
      .map(res => res.json() as Passenger)
      .catch(this.handleError);
    }


  private handleError(error: any): Promise<any> {
    console.error('Error', error); 
    return Promise.reject(error.message || error);
  }
}
