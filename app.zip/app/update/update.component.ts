import { Component, OnInit } from '@angular/core';
import { Passenger } from '../passenger';
import { PassengerService } from '../passenger.service';
import { Router, ActivatedRoute } from '@angular/router';

@Component({
  selector: 'app-update',
  templateUrl: './update.component.html',
  styleUrls: ['./update.component.css'],
  providers:[PassengerService]
})
export class UpdateComponent implements OnInit {

  passenger:Passenger;
  id:number;
  status:string;
  constructor(private passengerService:PassengerService,private router:Router,private route:ActivatedRoute) { }
 //id = this.route.snapshot.params['id'];
//  ngOnInit() {
//  }
  ngOnInit() {
    this.id=this.route.snapshot.params['id'];
    // console.log(this.id);
    // this.passengerService.getPassengerByBookingId1(this.id)
    // .subscribe(passenger=>this.passenger=passenger);
    return  this.passengerService.getPassengerByBookingId1(this.id)
     .subscribe(
       data => this.passenger = data); 
     }
  
     onSubmit(){
       return this.passengerService.updatePassenger(this.id).subscribe(passenger=>this.passenger=passenger);
     }

}
