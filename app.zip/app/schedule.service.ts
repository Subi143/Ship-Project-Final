import { Injectable } from '@angular/core';
import { Schedule } from './schedule';
import { Headers,Http } from '@angular/http';
import { Observable } from 'rxjs';
import 'rxjs/add/operator/map';
import 'rxjs/add/operator/catch';
import { Ship } from './ship';

@Injectable()
export class ScheduleService {

 private Url ='http://localhost:8089/ShipProject/schedules';
  schedulelist:Schedule[];
  private headers = new Headers({'Content-Type':'application/json'})

  constructor(private _http:Http) { }


  getSchedules():Observable<Schedule[]>{
    return this._http.get(this.Url)
    .map(res => res.json() as Schedule)
    .catch(this.handleError);
  }

  getSchedule(source:String,destination:String,departure:String):Observable<Schedule[]> {
    const url='http://localhost:8089/ShipProject/schedule/';
    const getflightUrl=`${url}/${source}/${destination}/${departure}`;
    return this._http.get(getflightUrl,{headers :this.headers})
    .map(response => response.json() as Schedule)
    .catch(this.handleError);
    
  }




  
  private handleError(error: any): Promise<any> {
    console.error('Error', error); 
    return Promise.reject(error.message || error);
  }
}
