import { Routess } from "./routess";
import { Ship } from "./ship";

export class Schedule {
    public id: number;
	public ship: Ship[];
	public route: Routess[];
	public departure: Date;
	public arrival: Date;
	public departuretime: string;
	public arrivaltime: string;
	public num_booked_seat: number;
	public num_seat_left: number;
}
