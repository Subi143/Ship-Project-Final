import { Component, OnInit } from '@angular/core';
import { Schedule } from '../schedule';
import { ScheduleService } from '../schedule.service';
import { Router } from '@angular/router';
import { Ship } from '../ship';
import { Routess } from '../routess';

@Component({
  selector: 'app-schedule-details',
  templateUrl: './schedule-details.component.html',
  styleUrls: ['./schedule-details.component.css'],
  providers: [ScheduleService]
})
export class ScheduleDetailsComponent implements OnInit {
  schedules : Schedule[];
  statusCode: number;
  constructor(private _scheduleService : ScheduleService) { }

  ngOnInit() {
      this.getSchedules();
  }
  getSchedules(){
    this._scheduleService.getSchedules()
      .subscribe(
        data => this.schedules = data,
        errorcode => this.statusCode = errorcode);
  }

}