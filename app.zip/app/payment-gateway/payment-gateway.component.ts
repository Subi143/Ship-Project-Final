import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-payment-gateway',
  templateUrl: './payment-gateway.component.html',
  styleUrls: ['./payment-gateway.component.css']
})
export class PaymentGatewayComponent implements OnInit {

  constructor(private router: Router) { }

  ngOnInit() {
  }
 
  private save(): void {
  
    this.router.navigate(['/success']);
  }

  onSubmit() {
 
    this.save();
  }

}
