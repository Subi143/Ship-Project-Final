import { Schedule } from "./schedule";
import { Customer } from "./customer";

export class Passenger {

    public booking_id: number;
	public fname: string;
	public mname: string;
	public lname: string;
	public age: number;
	public gender: string;
	public seatno: number;
	public bookingdate: Date;
	public status: string;

	public schedule: Schedule[];

	public customer: Customer[];
}
