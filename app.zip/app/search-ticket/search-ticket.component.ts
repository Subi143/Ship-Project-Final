import { Component, OnInit } from '@angular/core';
import { PassengerService } from '../passenger.service';
import { Router } from '@angular/router';
import { Passenger } from '../passenger';
import { FormGroup, FormControl, Validators } from '../../../node_modules/@angular/forms';

@Component({
  selector: 'app-search-ticket',
  templateUrl: './search-ticket.component.html',
  styleUrls: ['./search-ticket.component.css'],
  providers: [PassengerService]

})
export class SearchTicketComponent implements OnInit {
  model: any = {};
  // loading = false;
   error = 'invalid ';
   passenger :Passenger[];
  // passengerDetails:PassengerDetails;
   statusCode: number;
   booking_id= 0;
   
   constructor(private _scheduleService: PassengerService,
     private router: Router){ } 
 
   ngOnInit() {
     //this.search();
   }
   private search(): any{
     return  this._scheduleService.getPassenger(this.model.booking_id)
     .subscribe(
       data => this.passenger = data,
       errorCode =>  this.statusCode = errorCode); 
     }

     bookForm = new FormGroup({
      status: new FormControl('', Validators.required)	   
  });

    //  loadToCancel(booking_id:number){
    //   this._scheduleService.getPassengerByBookingId(booking_id).subscribe( book => {
    //     this.booking_id = book.booking_id;   
    //     this.bookForm.setValue({status: book.status});
    //   );

    //  }
    // loadToCancel(booking_id:number){
    //   this.router.navigate(['/update',booking_id]);
    // }
    }