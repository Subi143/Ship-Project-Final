export class Customer {
    public id: number;
	public fname: string;
	public mname: string;
	public lname: string;
	public gender: string;
	public age: number;
	public mobile: number;
	public email: string;
	public password: string;
	public govtid: string;
	public address: string;
}
