
import { Component, OnInit } from '@angular/core';
import { Router } from '../../../node_modules/@angular/router';
import { CustomerService } from '../customer.service';
import { UserService } from '../user.service';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css'],
  providers: [ UserService ]
})
export class LoginComponent  {

  model: any = {};
  loading = false;
  error = 'invalid';

  constructor(
    private router: Router,
    private _customerService: UserService) { }

  ngOnInit() {
    
  }
  login() {
   // this.loading = true;
this.router.navigate(['/add']);
    this._customerService.login(this.model.email,this.model.password)
        .then(result => {
            if (result === true) {
                // login successful
                this.router.navigateByUrl('add'); 
            } else {
                // login failed
                
               
                console.log("sinsdfgh");
                this.error = 'Username or password is incorrect';
                this.loading = false;
                console.log(this.error); 
                this.router.navigateByUrl('login');
            }
        }, error => {
          this.loading = false;
          this.error = error;
       
        });
}


}


 