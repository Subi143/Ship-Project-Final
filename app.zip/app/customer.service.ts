import { Injectable } from '@angular/core';
import { Customer } from './customer';
import { Headers,Response, Http } from '@angular/http';
import { Observable } from 'rxjs';
import 'rxjs/add/operator/map';
import 'rxjs/add/operator/catch';


@Injectable()
export class CustomerService {

  private  headers =new Headers({'Content-Type':'application/json'});
  constructor(private _http:Http) { }

  /* getCustomers(): Promise<Customer[]>{
    
    return this._http.get('http://localhost:8089/ShipProject/customers')
     .toPromise()
     .then(response =>{response.json() as Customer, console.log(response)})
    .catch(this.handleError)
  } */
  
  private extractData(res: Response){
    let body= res.json();
    return body;
  }
 
 getCustomers():Observable<Customer[]> {
  return this._http.get("http://localhost:8089/ShipProject/customers")
      .map(this.extractData).catch(this.handleError); 
 }




  getCustomerById(id: number): Observable<Customer> {
    return this._http.get("http://localhost:8089/ShipProject/customer/" + id)
        .map((response: Response) => <Customer>response.json())
        .catch(this.handleError);
}


  updateCustomer(customer: Customer,id: number):Promise<any>{

     return this._http.put('http://localhost:8089/ShipProject/customer/${id}',
                        JSON.stringify(customer),
                        {headers: this.headers})
                        .toPromise()
                        .then(res => res.json() as Customer)
                        .catch(this.handleError);
  }


  private handleError(error: any): Promise<any> {
    console.error('Error', error); 
    return Promise.reject(error.message || error);
  }
}
