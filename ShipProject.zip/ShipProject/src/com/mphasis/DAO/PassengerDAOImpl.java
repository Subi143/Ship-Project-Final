package com.mphasis.DAO;

import java.util.List;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.mphasis.entities.Passenger;
import com.thoughtworks.xstream.core.util.QuickWriter;

@Repository
public class PassengerDAOImpl implements PassengerDAO {

	@Autowired
	private SessionFactory sessionFactory;

	public void setSessionFactory(SessionFactory sessionFactory) {
		this.sessionFactory = sessionFactory;
	}

	@Override
	public Passenger addPassenger(Passenger passenger) {
		Session session = sessionFactory.getCurrentSession();
		Transaction transaction = session.beginTransaction();
		session.save(passenger);
		transaction.commit();
		return passenger;
	}

	@Override
	public void updatePassenger(Passenger passenger,int booking_id) {
		Session session = sessionFactory.getCurrentSession();
		Transaction transaction = session.beginTransaction();
		Query query = session.createQuery("update Passenger set status='CANCELLED' where booking_id=:booking_id");
		query.setParameter("booking_id", booking_id);
		int executeUpdate = query.executeUpdate();
		transaction.commit();
		System.out.println(executeUpdate+" rows got updated.");
	}

	@Override
	public List<Passenger> getPassenger(int booking_id) {
		Session session = sessionFactory.getCurrentSession();
		Transaction transaction = session.beginTransaction();
		Query query = session.createQuery("from Passenger where booking_id=:booking_id and status='CONFIRMED'");
		query.setParameter("booking_id", booking_id);
		List<Passenger> passenger =query.list();
		transaction.commit();
		return passenger;
	}

	@Override
	public void deletePassenger(int booking_id) {
		Session session = sessionFactory.getCurrentSession();
		Transaction transaction = session.beginTransaction();
		String hql = "delete from Passenger where booking_id= :booking_id";
        Query query = session.createQuery(hql);
        query.setParameter("booking_id", booking_id);
        System.out.println(query.executeUpdate());
        transaction.commit();
	}

	@Override
	public void updatePassenger(int booking_id) {
		Session session = sessionFactory.getCurrentSession();
		Transaction transaction = session.beginTransaction();
		Query query = session.createQuery("update Passenger set status='CANCELLED' where booking_id=:booking_id");
		query.setParameter("booking_id", booking_id);
		int executeUpdate = query.executeUpdate();
		transaction.commit();
		System.out.println(executeUpdate+" rows got updated.");
	}

}
