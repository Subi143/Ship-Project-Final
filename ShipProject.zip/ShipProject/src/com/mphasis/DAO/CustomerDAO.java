package com.mphasis.DAO;

import java.util.List;

import com.mphasis.entities.Customer;

public interface CustomerDAO {
	public Customer getDetails(int id);
	public void editDetails(Customer customer,int id);
	public List<Customer> getAllCustomers();

}
