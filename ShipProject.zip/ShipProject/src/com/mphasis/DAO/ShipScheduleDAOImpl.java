package com.mphasis.DAO;



import java.util.Date;
import java.util.List;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.mphasis.entities.Schedule;

@Repository
public class ShipScheduleDAOImpl implements ShipScheduleDAO {
	@Autowired
	SessionFactory sessionFactory;
	
	public void setSessionFactory(SessionFactory sessionFactory) {
		this.sessionFactory = sessionFactory;
	}

	@Override
	public List<Schedule> getAllSchedule() {
		Session session=sessionFactory.getCurrentSession();
		Transaction trans=session.beginTransaction();
		List<Schedule> c=session.createQuery("from Schedule").list();
		trans.commit();
		return c;
	}

	@Override
	public List<Schedule> getParticularSchedule(String source, String destination, Date departure) {
		Session session=sessionFactory.getCurrentSession();
		Transaction trans=session.beginTransaction();
		Query query=session.createQuery("from Schedule where route_route_id=(select route_id from Route where source=:source and destination=:destination) and departure=:departure");
		query.setParameter("source", source);
		query.setParameter("destination", destination);
		query.setParameter("departure", departure);
		List<Schedule> s=query.list();
		 trans.commit();
		return s;
	}

}
