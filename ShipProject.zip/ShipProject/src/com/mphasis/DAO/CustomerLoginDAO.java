package com.mphasis.DAO;

import com.mphasis.entities.Customer;

public interface CustomerLoginDAO {
	public Customer signIn(String email, String password);
}
