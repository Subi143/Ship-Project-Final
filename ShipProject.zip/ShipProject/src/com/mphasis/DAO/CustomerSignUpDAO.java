package com.mphasis.DAO;

import java.util.List;

import com.mphasis.entities.Customer;



public interface CustomerSignUpDAO {
	public void addCustomer(Customer customer);
	public List<Customer> listCustomer();
}
