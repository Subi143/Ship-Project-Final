package com.mphasis.DAO;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.mphasis.entities.Customer;




@Repository
public class CustomerLoginDAOImpl implements CustomerLoginDAO {
	@Autowired
	SessionFactory sessionFactory;

	public void setSessionFactory(SessionFactory sessionFactory) {
		this.sessionFactory = sessionFactory;
	}

	public Customer signIn(String email, String password) {
		System.out.println("Dao Called");
		Session session = sessionFactory.getCurrentSession();
		Transaction transaction = session.beginTransaction();
		Query query = session.createQuery("from Customer where email=:email and password=:password");
		query.setParameter("email", email);
		query.setParameter("password", password);
		Customer customer=(Customer) query.uniqueResult();
		transaction.commit();
		return customer;
	}

}
