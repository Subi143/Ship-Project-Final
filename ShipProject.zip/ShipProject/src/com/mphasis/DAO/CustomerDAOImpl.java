package com.mphasis.DAO;

import java.util.List;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.mphasis.entities.Customer;
import com.mphasis.entities.Passenger;
import com.mphasis.entities.Schedule;

@Repository

public class CustomerDAOImpl implements CustomerDAO {
	@Autowired
	SessionFactory sessionFactory;
	
	public void setSessionFactory(SessionFactory sessionFactory) {
		this.sessionFactory = sessionFactory;
	}

	@Override
	public Customer getDetails(int id) {
		Session session=sessionFactory.getCurrentSession();
		Transaction trans=session.beginTransaction();
		Query query = session.createQuery("from Customer where id=:id");
		query.setParameter("id", id);
		Customer passenger = (Customer) query.uniqueResult();
		trans.commit();
		return passenger;
	}

	@Override
	public void editDetails(Customer customer,int id) {
		Session session=sessionFactory.getCurrentSession();
		Transaction trans=session.beginTransaction();
	
		session.update(customer);
		trans.commit();
		
	}

	@Override
	public List<Customer> getAllCustomers() {
		Session session=sessionFactory.getCurrentSession();
		Transaction trans=session.beginTransaction();
		List<Customer> c=session.createQuery("from Customer").list();
		trans.commit();
		return c;
	}

}
