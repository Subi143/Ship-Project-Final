package com.mphasis.DAO;

import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.mphasis.entities.Customer;



@Repository
public class CustomerSignUpDAOImpl implements CustomerSignUpDAO {

	@Autowired
	private SessionFactory sessionFactory;

	public void setSessionFactory(SessionFactory sessionFactory) {
		this.sessionFactory = sessionFactory;
	}

	@Override
	public void addCustomer(Customer customer) {
		Session session = sessionFactory.getCurrentSession();
		Transaction tran = (Transaction) session.beginTransaction();
		session.save(customer);
		tran.commit();
	}

	@SuppressWarnings("unchecked")
	@Override
	public List<Customer> listCustomer() {
		Session session=sessionFactory.getCurrentSession();
		Transaction tran=(Transaction) session.beginTransaction();
		List<Customer> customer=session.createQuery("from Customer").list();
		tran.commit();
		return customer ;
	}
}
