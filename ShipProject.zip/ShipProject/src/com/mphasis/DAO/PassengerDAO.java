package com.mphasis.DAO;

import java.util.List;

import com.mphasis.entities.Passenger;

public interface PassengerDAO {
	public Passenger addPassenger(Passenger passenger);
	public void updatePassenger(Passenger passenger,int id);
	public void updatePassenger(int id);
    public List<Passenger> getPassenger(int id);
    public void deletePassenger(int id);
}
