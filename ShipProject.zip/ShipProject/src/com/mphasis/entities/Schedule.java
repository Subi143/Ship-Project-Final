package com.mphasis.entities;

import java.io.Serializable;
import java.sql.Date;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

import javax.persistence.OneToMany;
import javax.persistence.OneToOne;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
@Entity
public class Schedule implements Serializable{

	@Id
	@GeneratedValue(strategy=GenerationType.SEQUENCE)
	private int id;
	@OneToOne
	private Ship ship;
	@OneToOne
	private Route route;
	private Date departure;
	private Date arrival;
	private String departuretime;
	private String arrivaltime;
	
	private int num_booked_seat;
	private int num_seat_left;
	@OneToMany(mappedBy="schedule",fetch = FetchType.EAGER, cascade = CascadeType.ALL)
	@JsonIgnoreProperties("schedule")
	private List<Passenger> passengers;
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public Ship getShip() {
		return ship;
	}
	public void setShip(Ship ship) {
		this.ship = ship;
	}
	public Route getRoute() {
		return route;
	}
	public void setRoute(Route route) {
		this.route = route;
	}
	public Date getDeparture() {
		return departure;
	}
	public void setDeparture(Date departure) {
		this.departure = departure;
	}
	public Date getArrival() {
		return arrival;
	}
	public void setArrival(Date arrival) {
		this.arrival = arrival;
	}
	public int getNum_booked_seat() {
		return num_booked_seat;
	}
	public void setNum_booked_seat(int num_booked_seat) {
		this.num_booked_seat = num_booked_seat;
	}
	public int getNum_seat_left() {
		return num_seat_left;
	}
	public void setNum_seat_left(int num_seat_left) {
		this.num_seat_left = num_seat_left;
	}
	public List<Passenger> getPassengers() {
		return passengers;
	}
	public void setPassengers(List<Passenger> passengers) {
		this.passengers = passengers;
	}
	
	@Override
	public String toString() {
		return "Schedule [id=" + id + ", ship=" + ship + ", route=" + route + ", departure=" + departure + ", arrival="
				+ arrival + ", departuretime=" + departuretime + ", arrivaltime=" + arrivaltime + ", num_booked_seat="
				+ num_booked_seat + ", num_seat_left=" + num_seat_left + ", passengers=" + passengers + "]";
	}
	public String getDeparturetime() {
		return departuretime;
	}
	public void setDeparturetime(String departuretime) {
		this.departuretime = departuretime;
	}
	public String getArrivaltime() {
		return arrivaltime;
	}
	public void setArrivaltime(String arrivaltime) {
		this.arrivaltime = arrivaltime;
	}
	

	
}
