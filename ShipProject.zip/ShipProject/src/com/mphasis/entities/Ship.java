package com.mphasis.entities;

import java.io.Serializable;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@Entity
public class Ship implements Serializable{
	
	@Id
	@GeneratedValue(strategy=GenerationType.SEQUENCE)
	private int id;
	private String name;
	private int capacity;
	private int concapacity;
	private int wlcapacity;

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public int getCapacity() {
		return capacity;
	}

	public void setCapacity(int capacity) {
		this.capacity = capacity;
	}

	public int getConcapacity() {
		return concapacity;
	}

	public void setConcapacity(int concapacity) {
		this.concapacity = concapacity;
	}

	public int getWlcapacity() {
		return wlcapacity;
	}

	public void setWlcapacity(int wlcapacity) {
		this.wlcapacity = wlcapacity;
	}

	@Override
	public String toString() {
		return "Ship [id=" + id + ", name=" + name + ", capacity=" + capacity + ", concapacity=" + concapacity
				+ ", wlcapacity=" + wlcapacity + "]";
	}

	
}
