package com.mphasis.config;


import java.util.Properties;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.EnableAspectJAutoProxy;

import org.springframework.jdbc.datasource.DriverManagerDataSource;
import org.springframework.orm.hibernate4.LocalSessionFactoryBean;

import org.springframework.web.servlet.config.annotation.CorsRegistry;
import org.springframework.web.servlet.config.annotation.EnableWebMvc;

import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurerAdapter;






@Configuration
@EnableAspectJAutoProxy
@EnableWebMvc
@ComponentScan(basePackages="com.mphasis")
public class AppConfig {

	@Bean
public DriverManagerDataSource getDataSource() {
	DriverManagerDataSource ds=new DriverManagerDataSource();
	ds.setDriverClassName("oracle.jdbc.OracleDriver");
	ds.setUrl("jdbc:oracle:thin:@10.96.177.28:1521:xe");
	ds.setUsername("rohini");
	ds.setPassword("rohini");
	return ds;
}
@Bean
public LocalSessionFactoryBean getSessionFactory() {
	LocalSessionFactoryBean sessionFactory=new LocalSessionFactoryBean();
	sessionFactory.setDataSource(getDataSource());
	//sessionFactory.setAnnotatedClasses(Customer.class);
	//sessionFactory.setAnnotatedPackages("com.mphasis.entities");
	sessionFactory.setPackagesToScan("com.mphasis.entities");
	Properties props=new Properties();
	props.put("hibernate.dialect", "org.hibernate.dialect.OracleDialect");
	props.put("hibernate.hbm2ddl.auto", "update");
	props.put("hibernate.show_sql","true");
	props.put("hibernate.format_sql","true");
	props.put("hibernate.current_session_context_class","thread");
	sessionFactory.setHibernateProperties(props);
	return sessionFactory;
	
}
@Bean
public WebMvcConfigurer corsConfigurer() {
	return new WebMvcConfigurerAdapter() {
		@Override
		public void addCorsMappings(CorsRegistry registry) {
			registry.addMapping("/**").
			allowedMethods("HEAD","GET","POST","PUT","DELETE")
			.allowedHeaders("Origin","X-Requested-With","Content-Type","Accept");
			
		}
	};
}



}

