package com.mphasis.config;

import java.util.Arrays;

import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Before;
import org.springframework.stereotype.Component;

@Aspect
@Component
public class AspectHelper {
	@Before("execution(* com.mphasis.DAO.*.*(..))")
	public void beforeMethod(JoinPoint joinPoint) {
	System.out.println("Before DAO methods");
	System.out.println(joinPoint.getSignature().getName());
System.out.println(Arrays.toString(joinPoint.getArgs()));
}
	
}
