package com.mphasis.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.mphasis.Service.CustomerService;
import com.mphasis.entities.Customer;
import com.mphasis.entities.Schedule;

@RestController
public class CustomerController {
	@Autowired
	CustomerService customerService;

	public void setCustomerService(CustomerService customerService) {
		this.customerService = customerService;
	}
	@GetMapping(value="/customers",produces=MediaType.APPLICATION_JSON_VALUE)
	public List<Customer> getShipSchedule() {
		return customerService.getAllCustomers();
	}

	@GetMapping(value = "/customer/{id}", produces = MediaType.APPLICATION_JSON_VALUE)
	public Customer getCustomer(@PathVariable("id") int id) {
		return customerService.getDetails(id);
	}

	@PutMapping(value = "/customer/{id}", produces = MediaType.APPLICATION_JSON_VALUE)
	public void editCustomer(@RequestBody Customer customer,@PathVariable("id")int id) {
		customerService.editDetails(customer,id);

	}
	
	

}
