package com.mphasis.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.mphasis.Service.PassengerService;
import com.mphasis.entities.Passenger;

@RestController
public class PassengerController {

	@Autowired
	PassengerService passengerService;

	public void setPassengerService(PassengerService passengerService) {
		this.passengerService = passengerService;
	}
	
	@GetMapping(value = "/passenger/{id}", produces = MediaType.APPLICATION_JSON_VALUE)
	public List<Passenger> getPassenger(@PathVariable("id") int id) {
		return passengerService.getPassenger(id);
	}
	
	@PostMapping(value = "/add", produces = MediaType.APPLICATION_JSON_VALUE)
	public Passenger addPassenger(@RequestBody Passenger passenger) {
		return passengerService.addPassenger(passenger);
	}
	
	/*@PutMapping(value = "/edit/{id}", produces = MediaType.APPLICATION_JSON_VALUE)
	public void editPassenger(@RequestBody Passenger passenger,@PathVariable("id") int id) {
		passengerService.updatePassenger(passenger,id);
	}*/
	
	@PutMapping(value = "/edit/{id}", produces = MediaType.APPLICATION_JSON_VALUE)
	public void editPassenger(@PathVariable("id") int id) {
		passengerService.updatePassenger1(id);
	}
	
	
	
	@DeleteMapping(value = "/delete/{id}", produces = MediaType.APPLICATION_JSON_VALUE)
	public void deletePassenger(@PathVariable("id") int id) {
		passengerService.deletePassenger(id);
	}
}
