package com.mphasis.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

import org.springframework.web.bind.annotation.RestController;


import com.mphasis.Service.CustomerLoginService;
import com.mphasis.entities.Customer;



@RestController
public class CustomerLoginController {
	
	@Autowired
	CustomerLoginService fuserServicel;
	
	
	public void setFuserServicel(CustomerLoginService fuserServicel) {
		this.fuserServicel = fuserServicel;
	}


	@GetMapping(value="/login/{email}/{password}",produces= {MediaType.APPLICATION_JSON_VALUE})
	public boolean login(@PathVariable("email")String email ,@PathVariable("password")String password) {
	
		return fuserServicel.logIn(email, password);
	
		
	}

}
