package com.mphasis.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.mphasis.Service.CustomerSignUpService;
import com.mphasis.entities.Customer;


@RestController
public class CustomerSignUpController {

	@Autowired
	CustomerSignUpService customerService;

	public void setCustomerService(CustomerSignUpService customerService) {
		this.customerService = customerService;
	}

	@GetMapping(value = "/signup", produces = MediaType.APPLICATION_JSON_VALUE)
	public List<Customer> getAllCustomer() {
		List<Customer> customers = customerService.listCustomer();
		return customers;
	}

	@PostMapping(value = "/insert", produces = MediaType.APPLICATION_JSON_VALUE)
	public Customer addCustomer(@RequestBody Customer customer) {
		return customerService.addCustomer(customer);
	}

}
