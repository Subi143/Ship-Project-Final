package com.mphasis.Service;


import java.util.Date;
import java.util.List;

import com.mphasis.entities.Schedule;


public interface ShipScheduleService {
	public List<Schedule> getAllSchedule();
	public List<Schedule> getParticularSchedule(String source,String destination,Date departure);
	

}
