package com.mphasis.Service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.mphasis.DAO.PassengerDAO;
import com.mphasis.entities.Passenger;

@Service
public class PassengerServiceImpl implements PassengerService {

	@Autowired
	PassengerDAO passengerDAO;

	public void setPassengerDAO(PassengerDAO passengerDAO) {
		this.passengerDAO = passengerDAO;
	}

	@Override
	public Passenger addPassenger(Passenger passenger) {
		
		return passengerDAO.addPassenger(passenger);
	}

	@Override
	public void updatePassenger(Passenger passenger,int id) {
		passengerDAO.updatePassenger(passenger,id);
	}

	@Override
	public List<Passenger> getPassenger(int id) {
		return passengerDAO.getPassenger(id);	
	}

	@Override
	public void deletePassenger(int id) {
		passengerDAO.deletePassenger(id);
	}

	@Override
	public void updatePassenger1(int id) {
		passengerDAO.updatePassenger(id);
		
	}

}
