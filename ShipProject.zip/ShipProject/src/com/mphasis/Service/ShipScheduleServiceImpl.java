package com.mphasis.Service;

import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.mphasis.DAO.ShipScheduleDAO;
import com.mphasis.entities.Schedule;

@Service
public class ShipScheduleServiceImpl implements ShipScheduleService{
	@Autowired
	ShipScheduleDAO shipScheduleDAO;
	
	public void setShipScheduleDAO(ShipScheduleDAO shipScheduleDAO) {
		this.shipScheduleDAO = shipScheduleDAO;
	}

	@Override
	public List<Schedule> getAllSchedule() {
		return shipScheduleDAO.getAllSchedule();
	}

	@Override
	public List<Schedule> getParticularSchedule(String source, String destination, Date departure) {
		// TODO Auto-generated method stub
		return shipScheduleDAO.getParticularSchedule(source, destination, departure);
	}
	

}
