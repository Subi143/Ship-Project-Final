package com.mphasis.Service;

import java.util.List;

import com.mphasis.entities.Customer;
import com.mphasis.entities.Schedule;

public interface CustomerService {
	public Customer getDetails(int id);
	public void editDetails(Customer customer,int id);
	public List<Customer> getAllCustomers();
}
