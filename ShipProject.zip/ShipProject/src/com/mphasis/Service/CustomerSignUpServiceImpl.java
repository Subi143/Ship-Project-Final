package com.mphasis.Service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.mphasis.DAO.CustomerSignUpDAO;
import com.mphasis.entities.Customer;



@Service
public class CustomerSignUpServiceImpl implements CustomerSignUpService {
	
	@Autowired
	CustomerSignUpDAO customerdao;

	public void setPersonDao(CustomerSignUpDAO customerdao) {
		this.customerdao = customerdao;
	}

	@Override
	public Customer addCustomer(Customer customer) {
		customerdao.addCustomer(customer);
		return customer;

	}

	@Override
	public List<Customer> listCustomer() {
		List<Customer> customers=customerdao.listCustomer();
		return customers;
	}
}
