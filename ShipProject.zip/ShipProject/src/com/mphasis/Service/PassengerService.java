package com.mphasis.Service;

import java.util.List;

import com.mphasis.entities.Passenger;

public interface PassengerService {
	public Passenger addPassenger(Passenger passenger);
    public void updatePassenger(Passenger passenger,int id);
    public void updatePassenger1(int id);
    public List<Passenger> getPassenger(int id);
    public void deletePassenger(int id);
}
