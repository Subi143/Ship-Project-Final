package com.mphasis.Service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.mphasis.DAO.CustomerDAO;
import com.mphasis.entities.Customer;
@Service

public class CustomerServiceImpl implements CustomerService{
	@Autowired
	CustomerDAO customerDAO;
	
	public void setCustomerDAO(CustomerDAO customerDAO) {
		this.customerDAO = customerDAO;
	}

	@Override
	public Customer getDetails(int id) {
		// TODO Auto-generated method stub
		return customerDAO.getDetails(id);
	}

	@Override
	public void editDetails(Customer customer,int id) {
		customerDAO.editDetails(customer,id);
		
	}

	@Override
	public List<Customer> getAllCustomers() {
		
		return customerDAO.getAllCustomers();
	}
	

}
