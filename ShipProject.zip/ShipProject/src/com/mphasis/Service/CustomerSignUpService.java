package com.mphasis.Service;

import java.util.List;

import com.mphasis.entities.Customer;



public interface CustomerSignUpService {
	public Customer addCustomer(Customer customer);
	public List<Customer> listCustomer();
}
