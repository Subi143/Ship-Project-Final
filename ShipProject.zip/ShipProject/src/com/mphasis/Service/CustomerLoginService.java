package com.mphasis.Service;

import com.mphasis.entities.Customer;

public interface CustomerLoginService {
	public boolean logIn(String email, String password);

}
