package com.mphasis.Service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.mphasis.DAO.CustomerLoginDAO;
import com.mphasis.entities.Customer;

@Service
public class CustomerLoginServiceImpl implements CustomerLoginService {
	@Autowired
	private CustomerLoginDAO Dao;


	public void setDao(CustomerLoginDAO dao) {
		Dao = dao;
	}


	public boolean logIn(String email, String password) {


		System.out.println("service Called");
		Customer customer=Dao.signIn(email, password);
		if (customer!=null) {
			return true;
		}else {
		return false;
		}
	}
}
